#!/bin/bash

for i in `seq 0 1 1199`;
do echo $i;
cp ./all_10by10by10_samples/${i}.txt ./200each/fold1;
done
