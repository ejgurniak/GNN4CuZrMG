#!/bin/bash

for i in `seq 0 1 239`; do
	echo $i;
	declare -i fifteen_index=6*${i};
	declare -i thirteen_index=6*${i}+1;
	declare -i twelve_index=6*${i}+2;
	declare -i eleven_index=6*${i}+3;
	declare -i ten_index=6*${i}+4;
	declare -i nine_index=6*${i}+5;
	declare -i orig_index=${i}+1026;
	cp ../all_labeled_samples/2by2by2_15_${orig_index}.txt ./all_2by2by2_samples/${fifteen_index}.txt;
	cp ../all_labeled_samples/2by2by2_13_${orig_index}.txt ./all_2by2by2_samples/${thirteen_index}.txt;
	cp ../all_labeled_samples/2by2by2_12_${orig_index}.txt ./all_2by2by2_samples/${twelve_index}.txt;
	cp ../all_labeled_samples/2by2by2_11_${orig_index}.txt ./all_2by2by2_samples/${eleven_index}.txt;
	cp ../all_labeled_samples/2by2by2_10_${orig_index}.txt ./all_2by2by2_samples/${ten_index}.txt;
	cp ../all_labeled_samples/2by2by2_9_${orig_index}.txt ./all_2by2by2_samples/${nine_index}.txt;

done
