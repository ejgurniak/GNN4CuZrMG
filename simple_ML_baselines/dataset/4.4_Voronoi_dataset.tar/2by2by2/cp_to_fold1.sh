#!/bin/bash

for i in `seq 0 1 1199`;
do echo $i;
cp ./all_2by2by2_samples/${i}.txt ./200each/fold1;
done
