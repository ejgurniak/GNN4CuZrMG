#!/bin/bash

for i in `seq 0 1 239`; do
echo $i;
declare -i orig_index=${i}+1200;
cp ./all_7by7by7_samples/${orig_index}.txt ./target/${i}.txt
done
