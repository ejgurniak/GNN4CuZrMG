#!/bin/bash

for i in `seq 0 1 239`; do
	echo $i;
	declare -i fifteen_index=6*${i};
	declare -i thirteen_index=6*${i}+1;
	declare -i twelve_index=6*${i}+2;
	declare -i eleven_index=6*${i}+3;
	declare -i ten_index=6*${i}+4;
	declare -i nine_index=6*${i}+5;
	declare -i orig_index=${i}+1026;
	cp ../all_labeled_samples/7by7by7_15_${orig_index}.txt ./all_7by7by7_samples/${fifteen_index}.txt;
	cp ../all_labeled_samples/7by7by7_13_${orig_index}.txt ./all_7by7by7_samples/${thirteen_index}.txt;
	cp ../all_labeled_samples/7by7by7_12_${orig_index}.txt ./all_7by7by7_samples/${twelve_index}.txt;
	cp ../all_labeled_samples/7by7by7_11_${orig_index}.txt ./all_7by7by7_samples/${eleven_index}.txt;
	cp ../all_labeled_samples/7by7by7_10_${orig_index}.txt ./all_7by7by7_samples/${ten_index}.txt;
	cp ../all_labeled_samples/7by7by7_9_${orig_index}.txt ./all_7by7by7_samples/${nine_index}.txt;

done
